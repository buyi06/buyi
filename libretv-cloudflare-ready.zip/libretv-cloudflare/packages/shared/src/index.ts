
export type Env = {
  DB: D1Database
  KV_SESS: KVNamespace
  KV_CACHE: KVNamespace
  CORS_ORIGIN?: string
  CSP?: string
  JWT_SECRET: string
  ADMIN_EMAIL?: string
  ADMIN_PASSWORD?: string
}

export type User = {
  id: string
  email: string
  pass_hash: string
  role: 'admin' | 'member'
  created_at: number
}

export const json = (data: unknown) => Response.json(data, {
  headers: {'content-type': 'application/json; charset=utf-8'}
})

export function uid() { return crypto.randomUUID() }

export function now() { return Date.now() }
