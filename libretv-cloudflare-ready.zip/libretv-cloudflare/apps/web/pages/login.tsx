
import { useState } from 'react'
const API = process.env.NEXT_PUBLIC_API_BASE || 'http://127.0.0.1:8787'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [msg, setMsg] = useState('')

  async function submit(e:any){ 
    e.preventDefault()
    const r = await fetch(API + '/api/login', { method:'POST', credentials:'include', headers: {'content-type':'application/json'}, body: JSON.stringify({email, password}) })
    const j = await r.json()
    if (j.ok) location.href = '/'
    else setMsg(j.error || '登录失败')
  }

  return (
    <div className="container">
      <h1>登录</h1>
      <form onSubmit={submit}>
        <p><input placeholder="邮箱" value={email} onChange={e=>setEmail(e.target.value)} /></p>
        <p><input placeholder="密码" type="password" value={password} onChange={e=>setPassword(e.target.value)} /></p>
        <p><button type="submit">登录</button></p>
        {msg && <p style={{color:'crimson'}}>{msg}</p>}
      </form>
    </div>
  )
}
