import { useEffect, useState } from 'react'
const base = process.env.NEXT_PUBLIC_API_BASE || ''
export default function Home() {
  const [hello, setHello] = useState<any>(null)
  useEffect(() => {
    fetch(`${base}/api/hello`).then(r=>r.json()).then(setHello).catch(()=>{})
  }, [])
  return (
    <main style={{fontFamily:'system-ui', padding:24}}>
      <h1>LibreTV minimal (Web)</h1>
      <p>API base: <code>{base || '(same origin)'}</code></p>
      <pre style={{background:'#f5f5f5', padding:12, borderRadius:8}}>
        {JSON.stringify(hello, null, 2)}
      </pre>
    </main>
  )
}
