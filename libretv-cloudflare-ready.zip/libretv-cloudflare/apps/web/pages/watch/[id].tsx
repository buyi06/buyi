
import { useRouter } from 'next/router'
import { useEffect, useRef } from 'react'
const API = process.env.NEXT_PUBLIC_API_BASE || 'http://127.0.0.1:8787'

export default function Watch(){
  const ref = useRef<HTMLVideoElement>(null)
  const router = useRouter()
  const { id } = router.query

  useEffect(()=>{
    const v = ref.current
    if(!v) return
    const onTime = ()=>{
      if(!id) return
      fetch(API + '/api/progress', { method:'POST', credentials:'include', headers:{'content-type':'application/json'}, body: JSON.stringify({ vid: id, pos: v.currentTime }) })
    }
    const t = setInterval(onTime, 10_000)
    return ()=>clearInterval(t)
  },[id])

  return (
    <div className="container">
      <h1>播放：{id}</h1>
      <video ref={ref} controls style={{width:'100%',maxWidth:960,background:'#000'}} src="https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4"></video>
    </div>
  )
}
