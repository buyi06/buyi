import { Hono } from 'hono'
import { cors } from 'hono/cors'

type Bindings = {
  KV_SESS?: KVNamespace
  KV_CACHE?: KVNamespace
  DB?: D1Database
  ADMIN_EMAIL?: string
  ADMIN_PASSWORD?: string
}

const app = new Hono<{ Bindings: Bindings }>()

app.use('*', cors())

app.get('/', (c) => {
  return c.json({
    name: 'LibreTV minimal',
    status: 'ok',
    withKV: Boolean(c.env.KV_SESS || c.env.KV_CACHE),
    withD1: Boolean(c.env.DB),
  })
})

app.get('/healthz', (c) => c.text('ok'))

// Simple hello
app.get('/api/hello', (c) => {
  const now = new Date().toISOString()
  return c.json({ message: 'Hello from Worker', time: now })
})

// Optional bootstrap to set default admin in KV (if KV exists)
app.get('/__bootstrap', async (c) => {
  if (c.env.KV_SESS) {
    await c.env.KV_SESS.put('admin', JSON.stringify({
      email: c.env.ADMIN_EMAIL || 'admin@example.com',
      createdAt: new Date().toISOString()
    }))
    return c.json({ ok: true, bootstrapped: true, using: 'KV_SESS' })
  }
  return c.json({ ok: true, bootstrapped: false, reason: 'KV not bound (optional)' })
})

// Simple login demo (no real security; for demo only)
app.post('/auth/login', async (c) => {
  const body = await c.req.json().catch(() => ({} as any))
  const { email, password } = body || {}
  const ok = (email && password
    && email === (c.env.ADMIN_EMAIL || 'admin@example.com')
    && password === (c.env.ADMIN_PASSWORD || 'changeme'))
  if (ok) {
    if (c.env.KV_SESS) {
      await c.env.KV_SESS.put(`sess:${email}`, JSON.stringify({ email, t: Date.now() }), { expirationTtl: 86400 })
    }
    return c.json({ ok: true, email })
  }
  return c.json({ ok: false, error: 'invalid credentials' }, 401)
})

export default app
